create function demo_prueba(arg1 integer)
    returns TABLE(codas integer, nomper character varying, apepatper character varying, apematper character varying, tipasis character, estasis character, fechasis timestamp without time zone, justasis character varying)
    language plpgsql
as
$$
begin
    return query
        select
               a.CODAS,
               P.nomper,
               p.apepatper,
               p.apematper,
               a.TIPASIS,
               a.ESTASIS,
               a.FECHASIS,
               a.JUSTASIS

        from asistencia a
            INNER JOIN matricula m on a.codmat = m.codmat
            INNER JOIN usuario u on m.idusuestmat = u.idusu
            INNER JOIN persona p on u.idper = p.idper
        where A.idasig = arg1;

end;
$$;

alter function demo_prueba(integer) owner to postgres;

