create function demo(fecha integer) returns integer
    language plpgsql
as
$$
begin
select
       CODAS, a.fechasis, p.IDPER,P.nomper,p.apepatper,p.apematper,TIPASIS,
       ESTASIS, to_char( FECHASIS, 'YYYY-MM-DD'),
       JUSTASIS,
       a.idasig

from asistencia a
INNER JOIN matricula m on a.codmat = m.codmat
INNER JOIN usuario u on m.idusuestmat = u.idusu
INNER JOIN persona p on u.idper = p.idper
where A.idasig = fecha;
end;
$$;

alter function demo(integer) owner to postgres;

